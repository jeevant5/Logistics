package com.itc.repository;

import java.util.HashMap;
import java.util.Map;

import com.itc.entities.Vehicle;

public class VehicleRepository
        implements Repository<Vehicle, String> {

    private Map<String, Vehicle> vehicles;

    public VehicleRepository() {
        vehicles = new HashMap<>();
    }

    @Override
    public void save(Vehicle entity) {

        vehicles.put(
                entity.getVehicleId(),
                entity
        );

        System.out.println(
                "Vehicle saved: "
                + entity.getVehicleId()
        );
    }

    @Override
    public Vehicle findById(String id) {

        return vehicles.get(id);
    }
}
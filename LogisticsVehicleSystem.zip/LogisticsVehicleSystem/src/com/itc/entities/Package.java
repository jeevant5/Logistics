package com.itc.entities;

public class Package {

    private String packageId;
    private double weight;
    private boolean isPriority;

    public Package(String packageId, double weight, boolean isPriority) {
        this.packageId = packageId;
        this.weight = weight;
        this.isPriority = isPriority;
    }

    public String getPackageId() {
        return packageId;
    }

    public double getWeight() {
        return weight;
    }

    public boolean isPriority() {
        return isPriority;
    }

    public int getUrgencyScore() {
        return isPriority ? 10 : 1;
    }

    @Override
    public String toString() {
        return "Package ID: " + packageId
                + ", Weight: " + weight
                + " kg, Priority: " + isPriority;
    }
}
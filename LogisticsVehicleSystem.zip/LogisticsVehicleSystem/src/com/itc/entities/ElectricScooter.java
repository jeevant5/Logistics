package com.itc.entities;

public class ElectricScooter extends Vehicle {

    private int batteryHealth;

    public ElectricScooter(String vehicleId,
            double maxCapacityKg,
            int batteryHealth) {

        super(vehicleId, maxCapacityKg);
        this.batteryHealth = batteryHealth;
    }

    @Override
    public double calculateEfficiency() {

        return batteryHealth * 1.5;
    }

    public int getBatteryHealth() {
        return batteryHealth;
    }
}
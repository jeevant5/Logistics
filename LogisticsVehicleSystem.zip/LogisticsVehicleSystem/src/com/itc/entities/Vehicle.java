package com.itc.entities;

import com.itc.exception.InsufficientFuelException;
import com.itc.exception.OverCapacityException;

public abstract class Vehicle {

    private String vehicleId;
    private double maxCapacityKg;
    private double currentFuelPercent;

    public Vehicle(String vehicleId, double maxCapacityKg) {
        this.vehicleId = vehicleId;
        this.maxCapacityKg = maxCapacityKg;
        this.currentFuelPercent = 0.0;
    }

    public abstract double calculateEfficiency();

    public void refuel(double amount) {

        currentFuelPercent += amount;

        if (currentFuelPercent > 100.0) {
            currentFuelPercent = 100.0;
        }

        System.out.println(
            "Current fuel: " + currentFuelPercent + "%"
        );
    }

    public void loadCargo(double weightKg)
            throws OverCapacityException {

        if (weightKg > maxCapacityKg) {

            throw new OverCapacityException(
                "Cargo weight " + weightKg
                + " kg exceeds maximum capacity of "
                + maxCapacityKg + " kg."
            );
        }

        System.out.println(
            "Cargo loaded successfully: "
            + weightKg + " kg"
        );
    }

    public void drive(double distanceKm)
            throws InsufficientFuelException {

        double fuelConsumed = distanceKm * 0.15;

        if (fuelConsumed > currentFuelPercent) {

            throw new InsufficientFuelException(
                "Insufficient fuel. Required: "
                + fuelConsumed
                + "%, Available: "
                + currentFuelPercent + "%"
            );
        }

        currentFuelPercent -= fuelConsumed;

        System.out.println(
            "Vehicle drove " + distanceKm + " km"
        );

        System.out.println(
            "Remaining fuel: "
            + currentFuelPercent + "%"
        );
    }

    public String getVehicleId() {
        return vehicleId;
    }

    public double getMaxCapacityKg() {
        return maxCapacityKg;
    }

    public double getCurrentFuelPercent() {
        return currentFuelPercent;
    }
    @Override
    public String toString() {
        return "Vehicle ID: " + vehicleId
                + ", Max Capacity: " + maxCapacityKg
                + " kg, Fuel: " + currentFuelPercent + "%";
    }
}
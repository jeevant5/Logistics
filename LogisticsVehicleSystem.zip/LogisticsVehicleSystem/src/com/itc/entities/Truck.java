package com.itc.entities;

import com.itc.service.GPSNavigable;

public class Truck extends Vehicle implements GPSNavigable {

    private int numberOfAxles;

    public Truck(String vehicleId, double maxCapacityKg,
            int numberOfAxles) {

        super(vehicleId, maxCapacityKg);
        this.numberOfAxles = numberOfAxles;
    }

    @Override
    public double calculateEfficiency() {

        return 100.0 /
                (numberOfAxles *
                (getCurrentFuelPercent() / 100.0));
    }

    @Override
    public void updateLocation(double lat, double lon) {

        System.out.println(
            "Truck " + getVehicleId()
            + " location updated to: "
            + lat + ", " + lon
        );
    }

    public int getNumberOfAxles() {
        return numberOfAxles;
    }
}
package com.itc.service;

import java.util.ArrayList;
import java.util.List;

public class GenericAuditLog<T> {

    private List<T> entries;

    public GenericAuditLog() {
        entries = new ArrayList<>();
    }

    public void addEntry(T item) {
        entries.add(item);
    }

    public T getLatestEntry() {

        if (entries.isEmpty()) {
            return null;
        }

        return entries.get(entries.size() - 1);
    }

    public List<T> getAllEntries() {
        return entries;
    }
}
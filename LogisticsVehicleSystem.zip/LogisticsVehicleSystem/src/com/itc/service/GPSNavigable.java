package com.itc.service;

public interface GPSNavigable {

    void updateLocation(double lat, double lon);

    default void pingServer() {
        System.out.println("Ping sent to central GPS server");
    }
}
package com.itc.demo;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.PriorityQueue;

import com.itc.entities.ElectricScooter;
import com.itc.entities.Package;
import com.itc.entities.Truck;
import com.itc.entities.Vehicle;
import com.itc.exception.InsufficientFuelException;
import com.itc.exception.OverCapacityException;
import com.itc.repository.VehicleRepository;
import com.itc.service.GenericAuditLog;
import com.itc.service.GPSNavigable;

public class LogisticsDemo {

    public static void main(String[] args) {

        // =====================================================
        // MODULE 1
        // Inheritance, Polymorphism, Abstract Class & Interface
        // =====================================================

        System.out.println("===== MODULE 1 =====");

        Truck truck = new Truck(
                "TR001",
                20000,
                6
        );

        ElectricScooter scooter = new ElectricScooter(
                "SC001",
                2000,
                80
        );

        truck.refuel(80);
        scooter.refuel(90);

        System.out.println(
                "Truck efficiency: "
                + truck.calculateEfficiency()
        );

        System.out.println(
                "Scooter efficiency: "
                + scooter.calculateEfficiency()
        );

        // Polymorphism
        Vehicle[] vehicles = {
                truck,
                scooter
        };

        for (Vehicle vehicle : vehicles) {

            System.out.println(
                    vehicle.getVehicleId()
                    + " efficiency = "
                    + vehicle.calculateEfficiency()
            );

            // instanceof pattern matching
            if (vehicle instanceof GPSNavigable gps) {

                gps.updateLocation(
                        12.9716,
                        77.5946
                );

                gps.pingServer();
            }
        }


        // =====================================================
        // MODULE 2
        // Exception Handling & Custom Exceptions
        // =====================================================

        System.out.println("\n===== MODULE 2 =====");

        // Test OverCapacityException
        try {

            scooter.loadCargo(5000);

        } catch (OverCapacityException e) {

            System.out.println(
                    "OverCapacityException: "
                    + e.getMessage()
            );

        } finally {

            System.out.println(
                    "Resource teardown completed."
            );
        }


        // Test InsufficientFuelException
        try {

            ElectricScooter lowFuelScooter =
                    new ElectricScooter(
                            "SC002",
                            2000,
                            80
                    );

            lowFuelScooter.refuel(10);

            lowFuelScooter.drive(100);

        } catch (InsufficientFuelException e) {

            System.out.println(
                    "InsufficientFuelException: "
                    + e.getMessage()
            );

        } finally {

            System.out.println(
                    "Fuel resource teardown completed."
            );
        }


        // =====================================================
        // MODULE 3
        // Java Collections Framework
        // =====================================================

        System.out.println("\n===== MODULE 3 =====");


        // -----------------------------------------------------
        // 1. ArrayList - Fleet Management
        // -----------------------------------------------------

        ArrayList<Vehicle> fleet =
                new ArrayList<>();

        fleet.add(truck);
        fleet.add(scooter);

        Truck truck2 = new Truck(
                "TR002",
                30000,
                8
        );

        fleet.add(truck2);

        System.out.println(
                "\nFleet before sorting:"
        );

        for (Vehicle vehicle : fleet) {

            System.out.println(
                    vehicle.getVehicleId()
                    + " -> "
                    + vehicle.getMaxCapacityKg()
                    + " kg"
            );
        }


        // Sort in descending order of capacity
        fleet.sort(
                Comparator.comparingDouble(
                        Vehicle::getMaxCapacityKg
                ).reversed()
        );

        System.out.println(
                "\nFleet after sorting:"
        );

        for (Vehicle vehicle : fleet) {

            System.out.println(
                    vehicle.getVehicleId()
                    + " -> "
                    + vehicle.getMaxCapacityKg()
                    + " kg"
            );
        }


        // -----------------------------------------------------
        // 2. PriorityQueue - Package Dispatch
        // -----------------------------------------------------

        PriorityQueue<Package> packageQueue =
                new PriorityQueue<>(
                        Comparator.comparingInt(
                                Package::getUrgencyScore
                        ).reversed()
                );

        packageQueue.add(
                new Package(
                        "PKG001",
                        100,
                        false
                )
        );

        packageQueue.add(
                new Package(
                        "PKG002",
                        50,
                        true
                )
        );

        packageQueue.add(
                new Package(
                        "PKG003",
                        200,
                        true
                )
        );

        System.out.println(
                "\nPackages by priority:"
        );

        while (!packageQueue.isEmpty()) {

            System.out.println(
                    packageQueue.poll()
            );
        }


        // -----------------------------------------------------
        // 3. HashMap - Driver Assignment
        // -----------------------------------------------------

        HashMap<String, Vehicle> driverAssignments =
                new HashMap<>();

        driverAssignments.put(
                "DL1001",
                truck
        );

        driverAssignments.put(
                "DL1002",
                scooter
        );

        driverAssignments.put(
                "DL1003",
                truck2
        );

        System.out.println(
                "\nDriver assignments:"
        );

        for (String license :
                driverAssignments.keySet()) {

            System.out.println(
                    license
                    + " -> "
                    + driverAssignments.get(license)
            );
        }

        // Search / lookup
        Vehicle assignedVehicle =
                driverAssignments.get("DL1001");

        System.out.println(
                "\nVehicle assigned to DL1001:"
        );

        System.out.println(
                assignedVehicle
        );


        // -----------------------------------------------------
        // 4. HashSet - Unique Inspection Log
        // -----------------------------------------------------

        HashSet<String> inspectionIds =
                new HashSet<>();

        inspectionIds.add("INSP001");
        inspectionIds.add("INSP002");
        inspectionIds.add("INSP003");

        // Duplicate entry
        inspectionIds.add("INSP001");

        System.out.println(
                "\nCompleted inspection IDs:"
        );

        for (String id : inspectionIds) {

            System.out.println(id);
        }


        // =====================================================
        // MODULE 4
        // Generics
        // =====================================================

        System.out.println("\n===== MODULE 4 =====");


        // -----------------------------------------------------
        // 1. GenericAuditLog<T>
        // -----------------------------------------------------

        GenericAuditLog<String> auditLog =
                new GenericAuditLog<>();

        auditLog.addEntry(
                "Truck TR001 started trip."
        );

        auditLog.addEntry(
                "Truck TR001 reached destination."
        );

        auditLog.addEntry(
                "Truck TR001 completed trip."
        );

        System.out.println(
                "\nLatest audit entry:"
        );

        System.out.println(
                auditLog.getLatestEntry()
        );

        System.out.println(
                "\nAll audit entries:"
        );

        for (String entry :
                auditLog.getAllEntries()) {

            System.out.println(entry);
        }


        // -----------------------------------------------------
        // 2. Bounded Generic
        // -----------------------------------------------------

        double totalCapacity =
                calculateTotalCapacity(fleet);

        System.out.println(
                "\nTotal fleet capacity: "
                + totalCapacity
                + " kg"
        );


        // -----------------------------------------------------
        // 3. Generic Repository
        // -----------------------------------------------------

        VehicleRepository repository =
                new VehicleRepository();

        repository.save(truck);
        repository.save(scooter);
        repository.save(truck2);

        Vehicle foundVehicle =
                repository.findById("TR001");

        System.out.println(
                "\nVehicle found in repository:"
        );

        System.out.println(
                foundVehicle
        );
    }


    // =========================================================
    // Bounded Generic Utility Method
    // =========================================================

    public static double calculateTotalCapacity(
            List<? extends Vehicle> vehicleList) {

        double total = 0;

        for (Vehicle vehicle : vehicleList) {

            total += vehicle.getMaxCapacityKg();
        }

        return total;
    }
}
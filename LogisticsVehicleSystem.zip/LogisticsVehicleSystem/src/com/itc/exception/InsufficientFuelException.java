package com.itc.exception;

public class InsufficientFuelException extends Exception {

    public InsufficientFuelException(String message) {
        super(message);
    }
}